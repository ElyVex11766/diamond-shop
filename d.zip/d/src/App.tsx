import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./i18n/LanguageContext";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Features } from "./pages/Features";
import { Docs } from "./pages/Docs";
import { Shop } from "./pages/Shop";
import { Dashboard } from "./pages/Dashboard";
import { Status } from "./pages/Status";
import { Login } from "./pages/Login";
import { NotFound } from "./pages/NotFound";
import { Bot } from "./pages/Bot"; // 👈 صفحه ربات اضافه شد

export default function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/features" element={<Features />} />
            <Route path="/docs" element={<Docs />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/status" element={<Status />} />
            <Route path="/login" element={<Login />} />
            <Route path="/bot" element={<Bot />} /> {/* 👈 مسیر ربات اضافه شد */}
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </LanguageProvider>
  );
}